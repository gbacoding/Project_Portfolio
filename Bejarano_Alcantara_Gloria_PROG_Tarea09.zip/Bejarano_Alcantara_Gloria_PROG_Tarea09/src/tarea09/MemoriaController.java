package tarea09;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.util.Duration;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaException;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Text;

/**
 * Clase Controladora
 * @author GLORIA BEJARANO ALCANTARA
 */
public class MemoriaController implements Initializable {

    // definición de variables internas para el desarrollo del juego
    private JuegoMemoria juego;         // instancia que controlará el estado del juego (tablero, parejas descubiertas, etc)
    private ArrayList<Button> cartas;   // array para almacenar referencias a las cartas @FXML definidas en la interfaz 
    private int segundos = 0;             // tiempo de juego
    private boolean primerBotonPulsado = false, segundoBotonPulsado = false; // indica si se han pulsado ya los dos botones para mostrar la pareja
    private int idBoton1, idBoton2;     // identificadores de los botones pulsados
    private boolean esPareja;           // almacenará si un par de botones pulsados descubren una pareja o no
    private String primeraCartaSeleccionada, segundaCartaSeleccionada;
    private int posicionPrimeraCartaEnTablero, posicionSegundaCartaEnTablero;
    private int intentos;               // contador intentos
    private String rutaMusica = getClass().getResource("/tarea09/assets/sonidos/HP_music_game.mp3").toString();
    private String rutaMusicaVictoria = getClass().getResource("/tarea09/assets/sonidos/musica_hp_victoria.mp3").toString();
    private String rutaArchivo, rutaAplausos;
    private Media musicaJuego, musicaAciertos, musicaError, musicaVictoria, aplausos;
    private MediaPlayer reproductorMusica, reproductorMusicaAciertos, reproductorMusicaError, reproductorVictoria, reproductorAplausos;
    private String modoDeJuego="";
    private int parejasDescubiertas;
    private boolean finalPartida;
    int numueroBotonesPulsados=0;
    
    @FXML private AnchorPane main;      // panel principal (incluye la notación @FXML porque hace referencia a un elemento de la interfaz)
    @FXML private ImageView background_hp;  // Fondo de la ventana
    @FXML private ImageView logo; // logo / titulo
    @FXML private ImageView fondo_decoracion_hp;
    @FXML private ImageView fondo_victoria;
    @FXML private ImageView card_game; // reverso carta del juego
    @FXML private ImageView vistaImagenSeleccionada; // carta a devolver por el boton
    @FXML private GridPane tablero; // tablero del juego
    @FXML private Button btn_iniciar; // boton que inicia la artida
    @FXML private Button btn_salir; // boton que sale del juego
    @FXML private Button btn1;
    @FXML private Button btn2;
    @FXML private Button btn3;
    @FXML private Button btn4;
    @FXML private Button btn5;
    @FXML private Button btn6;
    @FXML private Button btn7;
    @FXML private Button btn8;
    @FXML private Button btn9;
    @FXML private Button btn10;
    @FXML private Button btn11;
    @FXML private Button btn12;
    @FXML private Button btn13;
    @FXML private Button btn14;
    @FXML private Button btn15;
    @FXML private Button btn16;
    @FXML private Label label_intentos; // etiqueta intentos
    @FXML private Label label_tiempo; // etiqueta temporizador
    @FXML private Text txt_intentos; // texto numero de intentos actualizado
    @FXML private Text txt_temporizador; // texto temporizador actualizado
     
    // linea de tiempo para gestionar la finalización del intento al pasar 1.5 segundos
    private final Timeline finIntento = new Timeline(new KeyFrame(Duration.seconds(1.5), e -> finalizarIntento()));
    
    // linea de tiempo para gestionar el contador de tiempo del juego
    private Timeline contadorTiempo;

    /**
     * Método interno que configura todos los aspectos necesarios para inicializar el juego.
     *
     * @param url No utilizaremos este parámetro (null).
     * @param resourceBundle No utilizaremos este parámetro (null).
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        
        try {
            juego = new JuegoMemoria(); // instanciación del juego (esta instancia gestionará el estado de juego)
            juego.iniciarJuego();       // comienzo de una nueva partida
            cartas = new ArrayList<>(); // inicialización del ArrayList de referencias a cartas @FXML
            modoDeJuego = juego.getTipoPartida();
        } catch (Exception e){
            System.out.println("Error al inicializar el juego: " + e.getMessage());
        }
        
        // guarda en el ArrayList "cartas" todas las referencias @FXML a las cartas para gestionarlo cómodamente
        cartas.add(btn1);
        cartas.add(btn2);
        cartas.add(btn3);
        cartas.add(btn4);
        cartas.add(btn5);
        cartas.add(btn6);
        cartas.add(btn7);
        cartas.add(btn8);
        cartas.add(btn9);
        cartas.add(btn10);
        cartas.add(btn11);
        cartas.add(btn12);
        cartas.add(btn13);
        cartas.add(btn14);
        cartas.add(btn15);
        cartas.add(btn16);
        
        for (Button carta : cartas) {
            carta.setOnAction(this::mostrarContenidoCasilla); 
        }  
        
        // inicialización de todos los aspectos necesarios
        //reproductorVictoria.stop();
        fondo_victoria.setVisible(false);
        background_hp.setVisible(true);
        fondo_decoracion_hp.setVisible(true);
        logo.setVisible(true);
        intentos = 0;
        segundos = 0;
        primerBotonPulsado = false;//
        segundoBotonPulsado = false;//
        esPareja = false;//
        
        // contador de tiempo de la partida (Duration indica cada cuanto tiempo se actualizará)
        contadorTiempo = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
              /// acciones a realizar (este código se ejecutará cada segundo)
              segundos++;
              txt_temporizador.setText(String.valueOf(segundos));

        }));
        contadorTiempo.setCycleCount(Timeline.INDEFINITE);  // reproducción infinita
        contadorTiempo.play();                                // iniciar el contador en este momento
       
        // música de fondo para que se reproduzca cuando se inicia el juego
        try {
            musicaJuego = new Media(rutaMusica);
            reproductorMusica = new MediaPlayer(musicaJuego);
            reproductorMusica.setAutoPlay(true);
            reproductorMusica.setCycleCount(MediaPlayer.INDEFINITE); 
            reproductorMusica.play();
        } catch (MediaException e) {
            System.out.println("Archivo de audio no encontrado: " + e.getMessage());
        } catch (RuntimeException e) {
            System.out.println("No se puede reproducir el archivo: " + e.getMessage());
        }
        
    }
    
    /**
     * Acción asociada al botón <strong>Comenzar nuevo juego</strong> que permite comenzar una nueva partida.
     *
     * Incluye la notación @FXML porque será accesible desde la interfaz de usuario
     * @param event Evento que ha provocado la llamada a este método
     */
    @FXML  private void reiniciarJuego(ActionEvent event) {
        
        // detener el contador de tiempo 
        if (contadorTiempo != null) {
            contadorTiempo.stop();
        }
        
        // Reiniciar variables de control del juego
        segundos = 0;
        intentos = 0;
        txt_intentos.setText(String.valueOf(intentos));
        txt_temporizador.setText(String.valueOf(segundos));
        primerBotonPulsado = false;
        segundoBotonPulsado = false;
        esPareja = false;
         
        // detener la reproducción de la música de fondo
        if (reproductorVictoria!=null){
            reproductorVictoria.stop(); 
        }
                
        if (reproductorMusica!= null) {
            reproductorMusica.stop();
        }
        
        /* hacer visibles las 16 cartas de juego ya que es posible que no todas estén visibles 
           si se encontraron parejas en la partida anterior */
        for (Button carta : cartas) {
            carta.setVisible(true);
         }
        
        // Volver a poner la imagen del reverso en las cartas
            // Crear una lista temporal para almacenar las imágenes a eliminar
            List<Node> nodosAEliminar = new ArrayList<>();
            for (Node nodo : tablero.getChildren()) {
                if (nodo instanceof ImageView && nodo != null ) {
                    nodosAEliminar.add(nodo);
                }
            }

            // Eliminar los nodos almacenados en la lista
            tablero.getChildren().removeAll(nodosAEliminar);
        
        // llamar al método initialize para terminar de configurar la nueva partida
        initialize(null,null);
    }

    /**
     * Este método deberá llamarse cuando el jugador haga clic en cualquiera de las cartas del tablero.
     *
     * Incluye la notación @FXML porque será accesible desde la interfaz de usuario
     * @param event Evento que ha provocado la llamada a este método (carta que se ha pulsado)
     */
    @FXML  private void mostrarContenidoCasilla(ActionEvent event) {
        
        
        // Obtener cartas del tablero
        try {
            ArrayList<String> nuevaTablero = new ArrayList<>(juego.getTablero());
        } catch (NullPointerException e) {
            System.out.println("Error: El método juego.getTablero() devuelve null.");
        }
        // obtener el ID de la carta pulsada
        String cartaId = ((Button) event.getSource()).getId(); 
        
        // obtener la posicion del boton en el array de botones
        int posicionArrayBoton = encontrarPosicionBoton(cartas, cartaId);
      
        // Descubrir la imagen asociada a cada una de las cartas (y ajustar su tamaño al tamaño del botón)
        /* Obtener el valor de la carta que comparte indice con el btn
        del Array Botones */
        String cartaSeleccionada = juego.getCartaPosicion(posicionArrayBoton);
        
        // Obtener Filas y columnas en el Grid del boton pulsado 
        try {
            Button botonPulsado = (Button) event.getSource();
            Integer fila = GridPane.getRowIndex(botonPulsado);
            Integer columna = GridPane.getColumnIndex(botonPulsado);
            if (fila == null || columna == null) {
                System.out.println("Fila o columna no pueden ser null");
            }
       
        // Cargar imagen y añadirla al grid segun posicion del nodo
            Image img = new Image("/tarea09/assets/cartas/"+modoDeJuego+"/"+cartaSeleccionada+".jpg");
            vistaImagenSeleccionada = new ImageView(img);
            vistaImagenSeleccionada.setFitHeight(95);
            vistaImagenSeleccionada.setFitWidth(95);
            vistaImagenSeleccionada.setTranslateX(10);
            vistaImagenSeleccionada.setPreserveRatio(true);
            tablero.add(vistaImagenSeleccionada, columna, fila);
               
        // Gestionar correctamente la pulsación de las cartas (si es la primera o la segunda)
        if (primerBotonPulsado == false){
            primeraCartaSeleccionada = cartaSeleccionada;
            posicionPrimeraCartaEnTablero=posicionArrayBoton;
            primerBotonPulsado = true; 
                 
        } else if (segundoBotonPulsado==false){//evitar que sea valido pulsar dos veces la misma carta
            segundaCartaSeleccionada = cartaSeleccionada;
            posicionSegundaCartaEnTablero=posicionArrayBoton;
            segundoBotonPulsado=true;            
        } 
           
        // Identificar si se ha encontrado una pareja o no    
        if (primerBotonPulsado==true && segundoBotonPulsado==true){
            esPareja = juego.compruebaJugada(posicionPrimeraCartaEnTablero, posicionSegundaCartaEnTablero);
            if (esPareja==true){
                System.out.println("Son iguales");
                // reproducir el efecto de sonido correspondiente
                String rutaMusicaAciertos = getClass().getResource("/tarea09/assets/sonidos/acierto.mp3").toString();
                musicaAciertos = new Media(rutaMusicaAciertos);
                reproductorMusicaAciertos = new MediaPlayer(musicaAciertos);
                reproductorMusicaAciertos.setAutoPlay(true);
                reproductorMusicaAciertos.setCycleCount(1); 
                reproductorMusicaAciertos.play(); 
                
            } else if (esPareja==false) {
                System.out.println("No son iguales");
                // reproducir el efecto de sonido correspondiente
                String rutaMusicaError = getClass().getResource("/tarea09/assets/sonidos/error.mp3").toString();
                musicaError = new Media(rutaMusicaError);
                reproductorMusicaError = new MediaPlayer(musicaError);
                reproductorMusicaError.setAutoPlay(true);
                reproductorMusicaError.setCycleCount(1); 
                reproductorMusicaError.play();
            }
        }
            
                 // QUITAR DESPUES      
        System.out.println("Holi,\n" +"Boton pulsado: " +cartaId + "\nPsicion en Array botones: "+posicionArrayBoton+
            "\nCarta Seleccionada: "+cartaSeleccionada+ "\nFila: "+fila+
            "\nColumna: "+columna+"\nPrimera Carta seleccionada: "+primeraCartaSeleccionada+"   Posicion: "+
                +posicionPrimeraCartaEnTablero+"\nSegunda Carta Seleccionada: "+
                segundaCartaSeleccionada+"   Posicion: "+posicionSegundaCartaEnTablero+
                "\nIntentos: "+intentos+
                "\ngetter: "+juego.getParejasDescubiertas()+
                "\nFin partida: "+finalPartida+
                "\nEs pareja: "+esPareja);
        
        } catch (IllegalArgumentException e) {
            System.out.println("Imagen no encontrada" + e.getMessage());
        } catch (NullPointerException e) {
            System.out.println("Archivo Image no puede ser cargado en ImageView: " + e.getMessage());
        } catch (ClassCastException e) {
            System.out.println("El evento no proviene de un Button: " + e.getMessage());
        }
            
        // finalizar intento (usar el timeline para que haga la llamada transcurrido el tiempo definido)
        finalizarIntento();
    
    } 
    
    /**
     * Este método permite finalizar un intento realizado. Se pueden dar dos situaciones:
     * <ul>
     *    <li>Si se ha descubierto una pareja: en este caso se ocultarán las cartas desapareciendo del tablero. Además, 
     *    se debe comprobar si la pareja descubierta es la última pareja del tablero y en ese caso terminar la partida.</li>
     *    <li>Si NO se ha descubierto una pareja: las imágenes de las cartas deben volver a ocultarse (colocando su imagen a null).</li>
     * </ul>
     * Este método será interno y NO se podrá acceder desde la interfaz, por lo que NO incorpora notación @FXML.
     */  
    private void finalizarIntento() {
        
        if (esPareja==true){
            // hacer desaparecer del tablero las cartas seleccionadas si forman una pareja
            System.out.println("sisisisi");
            parejasDescubiertas++;
            // Lista de nodos a eliminar
            List<Node> nodosAEliminar = new ArrayList<>();
            for (Node nodo : tablero.getChildren()) {
                if (nodo instanceof ImageView && nodo != null ) {
                    nodosAEliminar.add(nodo);
                    
                }
            }
            
            // Eliminar imagenes asignadas a botones con retraso y Reset los nodos almacenados en la lista
            eliminarNodoConRetraso(tablero, nodosAEliminar);
            // Eliminar botones con retraso
            //eliminarBotonesConRetraso();
            tablero.getChildren().get(posicionPrimeraCartaEnTablero).setVisible(false);
            tablero.getChildren().get(posicionSegundaCartaEnTablero).setVisible(false);
            
        } else if (esPareja==false && primerBotonPulsado==true && segundoBotonPulsado==true){
            // ocultar las imágenes de las cartas seleccionadas si NO forman una pareja
            System.out.println("nononon");
            
            //Lista de nodos a eliminar
            List<Node> nodosFalsos = new ArrayList<>();
            for (Node nodo : tablero.getChildren()) {
                if (nodo instanceof ImageView && nodo != null ) {
                    nodosFalsos.add(nodo);
                }
            }
            
            // Eliminar los nodos almacenados en la lista 1seg despues de que se muestre la imagen
            eliminarNodoConRetraso(tablero, nodosFalsos);
        }
        
        // comprobar el final de partida 
        parejasDescubiertas = juego.getParejasDescubiertas();
        finalPartida = juego.compruebaFin();
        System.out.println("Final partida 2: "+finalPartida);
        // si es final de partida mostra el mensaje de victoria y detener el temporizador y la música
        if (finalPartida==true){
            reproductorMusica.stop();
            contadorTiempo.stop();
            cargarEscenaVictoria();
            try {
            rutaAplausos = getClass().getResource("/tarea09/assets/sonidos/aplausos.mp3").toString();
            aplausos = new Media(rutaAplausos);
            reproductorAplausos = new MediaPlayer(aplausos);
            reproductorAplausos.setAutoPlay(true);
            reproductorAplausos.setCycleCount(1); 
            reproductorAplausos.play();
            
            } catch (MediaException e) {
                System.out.println("Archivo de audio no encontrado: " + e.getMessage());
            } catch (RuntimeException e) {
                System.out.println("No se puede reproducir el archivo: " + e.getMessage());
            }  
        }
        
        // reset
        if (primerBotonPulsado==true && segundoBotonPulsado==true){
            primeraCartaSeleccionada=null;
            segundaCartaSeleccionada=null;
            primerBotonPulsado=false;
            segundoBotonPulsado=false;
            posicionPrimeraCartaEnTablero=-1;
            posicionSegundaCartaEnTablero=-1;
            esPareja=false;
            intentos++;
            txt_intentos.setText(String.valueOf(intentos));
            
        }
    }

    /**
     * Este método permite salir de la aplicación.
     * Debe mostrar una alerta de confirmación que permita confirmar o rechazar la acción
     * Al confirmar la acción la aplicación se cerrará (opcionalmente, se puede incluir algún efecto de despedida)
     * Incluye la notación @FXML porque será accesible desde la interfaz de usuario
     */      
    @FXML   private void salir() {       
        
        // Alerta de confirmación que permita elegir si se desea salir o no del juego
        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION);
        alerta.setTitle("Confirmacion Salida");
        alerta.setHeaderText("¿Seguro que quieres abandonar la partida?");
        
        // Botones de la Alerta
        ButtonType botonAlertaSalida = new ButtonType("Salir");
        ButtonType botonAlertaCancelar = new ButtonType("Cancelar");
        
        alerta.getButtonTypes().setAll(botonAlertaSalida, botonAlertaCancelar);
        
        //Mostrar la alerta y esperar a que se elija una opcion
        Optional<ButtonType> respuesta = alerta.showAndWait();
        if(respuesta.isPresent() && respuesta.get()== botonAlertaSalida){
            Alert alertaDespedida = new Alert(Alert.AlertType.INFORMATION);
            alertaDespedida.setTitle("HASTA PRONTO");
            alerta.setTitle("¡Adiós!");
            alertaDespedida.setContentText("!Ohh, vuelve pronto! ¡Te estaremos esperando!");
            alertaDespedida.show();
            Timeline retrasoAlerta = new Timeline(new KeyFrame(Duration.seconds(3), 
                    event -> Platform.exit()
                )
            );
            retrasoAlerta.play();  
        }

    }
    
    /**
     * Permtite encontrar la posición de un boton en el ArrayList<Button> cartas
     * @param listaBotones referencia del Array de Botones
     * @param nombreBoton nombre del boton a encontrar en la lista de botones del que queremos la referencia
     * @return i Entero con el indice del ArrayList<Button> cartas del boton solicitado. Devuelve -1 si el boton no se encuentra en el ArrayList
     */
    public static int encontrarPosicionBoton(ArrayList<Button> listaBotones, String nombreBoton) {
            for (int i = 0; i < listaBotones.size(); i++) {
                if (listaBotones.get(i).getId().equals(nombreBoton)) {
                   return i; // Devuelve la posición del elemento
                 }
        }
        return -1; // Si no se encuentra el valor, devuelve -1
    }
    
    /**
     * Permite eliminar el nodo pasado por parametro con unos 0.5 segundos de retraso
     * @param tablero GridPane al que corresponde el nodo
     * @param nodos Lista de nodos a eliminar 
     */
    public  void eliminarNodoConRetraso (GridPane tablero, List<Node> nodos){
        Timeline retrasoEliminacion = new Timeline(new KeyFrame(Duration.seconds(0.5), event -> {
                // Eliminar nodos
                tablero.getChildren().removeAll(nodos);
                nodos.clear();
                
                })
            );
            retrasoEliminacion.play();
    }
    
    /**
     * Carga todos los elementos de la pantalla final. Fondo, imagenes y musica. 1 segundo posterior a la eliminacion del tablero de la ultima pareja de cartas
     */
    public void cargarEscenaVictoria() {
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            try {
                musicaVictoria = new Media(rutaMusicaVictoria);
                reproductorVictoria = new MediaPlayer(musicaVictoria);
                reproductorVictoria.setAutoPlay(true);
                reproductorVictoria.setCycleCount(MediaPlayer.INDEFINITE); 
                reproductorVictoria.play();
            
            } catch (MediaException e) {
                System.out.println("Archivo de audio no encontrado: " + e.getMessage());
            } catch (RuntimeException e) {
                System.out.println("No se puede reproducir el archivo: " + e.getMessage());
            } 
            
            background_hp.setVisible(false);
            fondo_decoracion_hp.setVisible(false);
            logo.setVisible(false);
            fondo_victoria.setVisible(true);   
        }));
        timeline.play();
    }
    
    // Por ahora no funciona
    public void eliminarBotonesConRetraso (){
        Timeline retrasoEliminacion = new Timeline(new KeyFrame(Duration.seconds(0.2), event -> {
            tablero.getChildren().get(posicionPrimeraCartaEnTablero).setVisible(false);
            tablero.getChildren().get(posicionSegundaCartaEnTablero).setVisible(false);
                
        }));
        retrasoEliminacion.play();       
    }
}
